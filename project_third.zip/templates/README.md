tbis project uses CRUD and ORM

This project taught me how to use the Visual Studio SQLite extension also about lambda

Movie database program written in Python3 and SQLAlchemy database software

also i found out about this

from app import app

from app import db

with app.app_context():

... db.create_all()

to fix the application context error: https://flask.palletsprojects.com/en/1.1.x/appcontext/